//		  date: "16.09.2023" ,  --
   var DIR_img = "img/";

	var media = new Map();
	media = {
        "001":  { id:  1, 
			type: "image",
			label: "001",
			title: "ноль ноль один",			
			image:   DIR_img + "0N/001.jpg",  
			image_n: DIR_img + "0N/001.jpg",  
			image_s: DIR_img + "0N/001_s.jpg",  
			txt: " это картинка 001" ,
		},

        "002":  { id:  2, 
			type: "image",
			label: "002",
			title: "ноль ноль два",			
			image:   DIR_img + "0N/002.jpg",  
			image_n: DIR_img + "0N/002.jpg",  
			image_s: DIR_img + "0N/002_s.jpg", 
			txt: " это картинка 002" ,
		},

        "003":  { id:  3, 
			type: "image",
			label: "003",
			title: "ноль ноль три",			
			image: 	 DIR_img + "0N/003.jpg",  
			image_n: DIR_img + "0N/003.jpg",  
			image_s: DIR_img + "0N/003_s.jpg", 
			txt: " это картинка 003" ,
		},

        "000":  { id:  0, 
			type: "image",
			label: "000",
			title: "ноль ноль ноль",			
			image: 	 DIR_img + "0N/000.jpg",  
			image_n: DIR_img + "0N/000.jpg",  
			image_s: DIR_img + "0N/000_s.jpg", 			
			txt: " это картинка 000" ,
		},

		"00h":  { id:  0, 
			type: "image",
			label: "151.HEIC",
			title: "151.HEIC",			
			image: 	 DIR_img + "151.HEIC",  
			image_n: DIR_img + "151.HEIC",  
			image_s: DIR_img + "151.HEIC", 			
			txt: " это картинка 151.HEIC" ,
		},

/* */
  
	};




/*
QWERTYUIOPASDFGHJKLZXCVBNMQWERTY
*/